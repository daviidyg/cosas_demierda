function tiempo(){
    var API_KEY = "a456c65a89b44bf8ac6101713161207";
    var seleccion = $("option:selected").text();
    var link = "https://api.apixu.com/v1/current.json?key="+API_KEY+"&q="+seleccion;
    var request = new XMLHttpRequest;
    request.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
         var jsonstring = JSON.parse(this.responseText);
         var Localizacion = jsonstring.location.name;  
         var Region = jsonstring.location.region;   
         var temperatura = jsonstring.current.temp_c;
         var icono = jsonstring.current.condition.icon;
         console.log(jsonstring);
         escribir(Localizacion,Region, temperatura,icono);
        }
        function escribir (Localizacion, Region, temperatura, icono){
            var p1 = document.createElement("p");
            var p1texto = document.createTextNode("Localizacion: "+Localizacion);
            p1.appendChild(p1texto);
            var p2 = document.createElement("p");
            var p2texto = document.createTextNode("Región: "+Region);
            p2.appendChild(p2texto);    
            var p3 = document.createElement("p");
            var p3texto = document.createTextNode("Temperatura: "+temperatura);
            p3.appendChild(p3texto);
            var p4 = document.createElement("p");
            var p4texto = document.createTextNode("Localizacion: "+Localizacion);
            p4.appendChild(p4texto);
            var img = document.createElement("img");
            img.setAttribute("src",icono);
            document.getElementById("info").appendChild(p1);
            document.getElementById("info").appendChild(p2);
            document.getElementById("info").appendChild(p3);
            document.getElementById("info").appendChild(p4);
            document.getElementById("info").appendChild(img);
        }
      }; 
    request.open("GET",link,true);
    request.send(); 
}