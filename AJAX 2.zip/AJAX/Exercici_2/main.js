function tiempo5(){
    var API_KEY = "a456c65a89b44bf8ac6101713161207";
    var seleccion = $("option:selected").text();
    var link = "https://api.apixu.com/v1/current.json?key="+API_KEY+"&q="+seleccion;
    var jsontiempo = $.getJSON( link, function() {
      var Localizacion = jsontiempo.responseJSON.location.name;  
      var Region = jsontiempo.responseJSON.location.region; 
      var temperatura = jsontiempo.responseJSON.current.temp_c;
      var icono = jsontiempo.responseJSON.current.condition.icon;

      Escribir_ficha1();
      Escribir_ficha2();
      Escribir_ficha3();
      Escribir_ficha4();
      Escribir_ficha5();

      function Escribir_ficha1(){

      }
      function Escribir_ficha2(){
        
      }
      function Escribir_ficha3(){
        
      }
      function Escribir_ficha4(){
        
      }
      function Escribir_ficha5(){
        
      }
  })   
}
