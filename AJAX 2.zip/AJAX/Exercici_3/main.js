function tiempo(){
    var API_KEY = "a456c65a89b44bf8ac6101713161207";
    var seleccion = $("option:selected").text();
    var link = "https://api.apixu.com/v1/current.json?key="+API_KEY+"&q="+seleccion;
    var info = $.getJSON( link, function(){
        var titulo = info.responseJSON.location.name;
        // var fecha = info.responseJSON.forecast.forecastday[0].date;
        // console.log(fecha)
        escribir(titulo);
        function escribir(titulo){
            var fecha=$("<p>"+fecha+"<p>"); 
            var loc=$("<h2>"+titulo+"</h2>");
            $("#hoy").append(titulo);
            $("#hoy").append(loc);
        }
    }
    )
}