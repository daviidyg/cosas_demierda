    var API_KEY = "a456c65a89b44bf8ac6101713161207";
    var seleccion = "Barcelona";
    var link = "http://api.apixu.com/v1/forecast.json?key="+API_KEY+"&q="+seleccion+"&days=5";
    var jsontiempo = $.getJSON( link, function() {
      var date=[];
      var icon=[];
      var temp=[];
      var precision_lluvias=[];
      var humedad=[];
      var viento=[];

      date[0]=jsontiempo.responseJSON.forecast.forecastday[0].date;
      date[1]=jsontiempo.responseJSON.forecast.forecastday[1].date;
      date[2]=jsontiempo.responseJSON.forecast.forecastday[2].date;
      date[3]=jsontiempo.responseJSON.forecast.forecastday[3].date;
      date[4]=jsontiempo.responseJSON.forecast.forecastday[4].date;

      icon[0]=jsontiempo.responseJSON.forecast.forecastday[0].day.condition.icon;
      icon[1]=jsontiempo.responseJSON.forecast.forecastday[1].day.condition.icon;
      icon[2]=jsontiempo.responseJSON.forecast.forecastday[2].day.condition.icon;
      icon[3]=jsontiempo.responseJSON.forecast.forecastday[3].day.condition.icon;
      icon[4]=jsontiempo.responseJSON.forecast.forecastday[4].day.condition.icon;

      temp[0]=jsontiempo.responseJSON.forecast.forecastday[0].day.avgtemp_c;
      temp[1]=jsontiempo.responseJSON.forecast.forecastday[1].day.avgtemp_c;
      temp[2]=jsontiempo.responseJSON.forecast.forecastday[2].day.avgtemp_c;
      temp[3]=jsontiempo.responseJSON.forecast.forecastday[3].day.avgtemp_c;
      temp[4]=jsontiempo.responseJSON.forecast.forecastday[4].day.avgtemp_c;

      precision_lluvias[0]=jsontiempo.responseJSON.forecast.forecastday[0].day.avgtemp_c;
      precision_lluvias[1]=jsontiempo.responseJSON.forecast.forecastday[0].day.avgtemp_c;
      precision_lluvias[2]=jsontiempo.responseJSON.forecast.forecastday[0].day.avgtemp_c;
      precision_lluvias[3]=jsontiempo.responseJSON.forecast.forecastday[0].day.avgtemp_c;
      precision_lluvias[4]=jsontiempo.responseJSON.forecast.forecastday[0].day.avgtemp_c;
      
     
      escribir(date,icon, temp);
      
      function escribir(date, icon, temp){
          //fechas
          for (i=0;i<5;i++){
              $(".fechad"+i).text(date[i]);
          }
          //iconos
          for (i=0;i<5;i++){
            $("#dia"+i).attr("src",icon[i]);
            }

          //Temperaturas  
          for (i=0;i<5;i++){
              $(".temp"+i).text("Temperatura media: "+temp[i]+"ºC");
          }
      }
  })    
