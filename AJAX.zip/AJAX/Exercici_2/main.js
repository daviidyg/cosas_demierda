function tiempo(){
    var API_KEY = "a456c65a89b44bf8ac6101713161207";
    var seleccion = $("option:selected").text();
    var link = "https://api.apixu.com/v1/current.json?key="+API_KEY+"&q="+seleccion;
    var jsontiempo = $.getJSON( link, function() {
      var Localizacion = jsontiempo.responseJSON.location.name;  
      var Region = jsontiempo.responseJSON.location.region; 
      var temperatura = jsontiempo.responseJSON.current.temp_c;
      var icono = jsontiempo.responseJSON.current.condition.icon;
      escribir(Localizacion,Region,temperatura,icono);
      function escribir(Localizacion,Region,temperatura,icono){
            var loc=$("<p>Localizacion: "+Localizacion+"</p>");
            var reg=$("<p>Región: "+Region+"</p>");
            var temp=$("<p>Temperatura: "+temperatura+"ºC"+"</p>");
            var img=$('<img src='+icono+'></img');
            $("#info").append(loc);
            $("#info").append(reg);
            $("#info").append(temp);
            $("#info").append(img);
      }
  })   
}
